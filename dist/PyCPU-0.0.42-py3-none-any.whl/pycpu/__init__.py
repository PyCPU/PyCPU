__version__ = '0.0.9'

import PyCPU_CPP

def hello_world():

    PyCPU_CPP.hello_world()
